'use strict';

describe('test', function () {

  describe('dummy', function () {
    it('should pass this dummy test', function (done) {
      done();
    });
  });


});
