'use strict';
angular
  .module('com.module.booking',[]);