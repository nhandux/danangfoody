(function () {
  'use strict';
  angular.module('com.module.browser', []);
})();
