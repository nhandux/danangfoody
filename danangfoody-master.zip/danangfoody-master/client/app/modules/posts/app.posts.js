(function () {
  'use strict';
  angular.module('com.module.posts', []);

})();
