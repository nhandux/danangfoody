"use strict";

 angular.module('config', [])

.constant('ENV', {name:'development',apiUrl:'http://0.0.0.0:5000/api/',siteUrl:'http://0.0.0.0:5000'})

;