'use strict';

module.exports = function(Temp) {

};
