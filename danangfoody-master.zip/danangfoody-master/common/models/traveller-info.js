'use strict';

module.exports = function(Travellerinfo) {

};
