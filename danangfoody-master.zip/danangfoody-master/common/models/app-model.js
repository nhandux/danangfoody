module.exports = function (AppModel) {

};
