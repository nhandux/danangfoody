module.exports = function(AuthProvider) {

};
